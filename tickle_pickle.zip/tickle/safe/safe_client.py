#!/usr/bin/python3
import os
import json

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = bytes(json.dumps(s),'utf-8')
    with open("safe_users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
